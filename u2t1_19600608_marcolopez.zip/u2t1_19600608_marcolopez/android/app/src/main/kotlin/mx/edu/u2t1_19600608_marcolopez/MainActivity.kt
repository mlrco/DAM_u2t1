package mx.edu.u2t1_19600608_marcolopez

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
